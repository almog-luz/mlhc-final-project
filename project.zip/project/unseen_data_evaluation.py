from typing import List, Union, Any
import os
import json
import pandas as pd
import joblib

try:  # BigQuery optional
    from google.cloud import bigquery as bq  # type: ignore
except Exception:  # pragma: no cover
    bq = None  # type: ignore

from .extract import (
    get_first_admissions,
    get_demographics,
    get_vitals_48h,
    get_labs_48h,
    get_prescriptions_48h,
    get_procedures_48h,
)
from .features import build_features  # initial import (may be stale if file edited after kernel start)
import importlib


def run_pipeline_on_unseen_data(subject_ids: List[int], client: Union[Any, None]) -> pd.DataFrame:
    """Run inference pipeline on unseen patients (DuckDB or BigQuery backend).

    Parameters
    ----------
    subject_ids : list[int]
        Subject IDs to score.
    client : duckdb.Connection or bigquery.Client
        Connection handle. If a DuckDB connection is passed, expects MIMIC-III
        tables to be available with canonical names (admissions, patients,
        chartevents, labevents, prescriptions, procedureevents_mv, d_items,
        d_labitems). If a BigQuery client is passed, uses the pre-existing
        BigQuery extraction helpers.

    Returns
    -------
    pandas.DataFrame
        Columns: subject_id, mortality_proba, prolonged_LOS_proba, readmission_proba
    """
    # 1) First admission per subject and LOS >= 54h
    # Detect duckdb vs BigQuery by attribute presence
    # Be explicit: inspect the client's runtime type to decide which extraction path to use.
    if client is None:
        raise ValueError("client is None. Provide a duckdb.Connection or bigquery.Client instance.")
    client_module = getattr(client.__class__, '__module__', '')
    client_class = getattr(client.__class__, '__name__', '')
    # Runtime debug: report client class/module and requested subject count
    try:
        print(f"DEBUG: client_module={client_module}, client_class={client_class}, requested_subjects={len(subject_ids)}")
    except Exception:
        print("DEBUG: client info retrieval failed")

    cm = client_module.lower() if isinstance(client_module, str) else ''
    cc = client_class.lower() if isinstance(client_class, str) else ''
    # Heuristics: prefer detecting DuckDB by module name; otherwise detect BigQuery by module or class hints.
    is_duckdb = 'duckdb' in cm or 'duckdb' in cc
    is_bigquery = ('google.cloud' in cm) or ('bigquery' in cm) or ('bigquery' in cc)
    # Fallback: if client has 'execute' but not 'query', treat as DuckDB
    if not is_duckdb and not is_bigquery:
        is_duckdb = hasattr(client, 'execute') and not hasattr(client, 'query')
        is_bigquery = hasattr(client, 'query') and not is_duckdb
    print(f"DEBUG: resolved backend -> duckdb={is_duckdb}, bigquery={is_bigquery}")
    if is_duckdb:
        # --- DuckDB BRANCH (STRICT, NO FALLBACKS) ---
        if not subject_ids:
            raise ValueError("No subject_ids provided.")
        sid_list = ','.join(str(int(s)) for s in subject_ids)
        sql = f"""
            SELECT subject_id, hadm_id, admittime, dischtime, deathtime, admission_type,
                   admission_location, discharge_location, diagnosis, insurance, language,
                   marital_status, ethnicity
            FROM admissions
            WHERE subject_id IN ({sid_list})
            ORDER BY subject_id, admittime
        """
        try:
            df_all = client.execute(sql).fetchdf()
        except Exception as e:
            raise RuntimeError(f"Failed to query admissions table: {e}") from e
        if df_all.empty:
            raise RuntimeError("No admissions rows returned for supplied subject_ids; cannot proceed.")
        col_lower_map = {c.lower(): c for c in df_all.columns}
        for need in ['subject_id','hadm_id','admittime','dischtime']:
            if need not in df_all.columns and need in col_lower_map:
                df_all.rename(columns={col_lower_map[need]: need}, inplace=True)
        missing_req = [r for r in ['subject_id','hadm_id','admittime','dischtime'] if r not in df_all.columns]
        if missing_req:
            raise KeyError(f"Admissions missing required columns: {missing_req}")
        first_adm = df_all.sort_values(['subject_id','admittime']).groupby('subject_id', as_index=False).first()
    else:
        if bq is None:
            raise RuntimeError("BigQuery client not available and provided client is not DuckDB.")
        # BigQuery path: use existing helper
        first_adm = get_first_admissions(client, subject_ids)  # type: ignore[arg-type]
    # Runtime debug: At this point first_adm should have exactly one row per subject (pre LOS filter)
    print('DEBUG: first_adm.shape ->', getattr(first_adm, 'shape', 'N/A'))
    if first_adm.empty:
        raise RuntimeError("All admissions filtered out by LOS >=54h criterion; no subjects eligible for scoring.")
    first_adm['admittime'] = pd.to_datetime(first_adm['admittime'])
    first_adm['dischtime'] = pd.to_datetime(first_adm['dischtime'])
    first_adm['los_hours'] = (first_adm['dischtime'] - first_adm['admittime']).dt.total_seconds() / 3600.0
    # Apply same >=54h filter used during training to avoid leakage & align cohorts.
    first_adm = first_adm[first_adm['los_hours'] >= 54].copy()
    # Runtime debug: After LOS filter we might lose many subjects; ensure not all are filtered erroneously.
    print('DEBUG: remaining after LOS filter ->', len(first_adm))
    hadm_ids = first_adm['hadm_id'].dropna().astype(int).tolist()

    # 2) Extract modalities within 0-48h
    if is_duckdb:
        # --- DuckDB modality extraction (STRICT) ---
        sid_list = ','.join(str(int(s)) for s in first_adm['subject_id'].tolist())
        def _req_duck(sql: str, label: str) -> pd.DataFrame:
            try:
                dfm = client.execute(sql).fetchdf()
            except Exception as e:
                raise RuntimeError(f"Failed to query {label}: {e}") from e
            return dfm
        demo = _req_duck(f"SELECT subject_id, gender, dob, dod, expire_flag FROM patients WHERE subject_id IN ({sid_list})", 'patients')
        if hadm_ids:
            hadm_list = ','.join(str(int(h)) for h in hadm_ids)
            vitals = _req_duck(f"SELECT subject_id, hadm_id, charttime, itemid AS item_label, valuenum, valueuom FROM chartevents WHERE hadm_id IN ({hadm_list})", 'chartevents')
            labs = _req_duck(f"SELECT subject_id, hadm_id, charttime, itemid AS item_label, valuenum, value AS value_text, valueuom, flag FROM labevents WHERE hadm_id IN ({hadm_list})", 'labevents')
            rx = _req_duck(f"SELECT subject_id, hadm_id, startdate, enddate, drug, drug_type, formulary_drug_cd, route FROM prescriptions WHERE hadm_id IN ({hadm_list})", 'prescriptions')
            proc = _req_duck(f"SELECT subject_id, hadm_id, starttime, endtime, itemid AS item_label, ordercategoryname, ordercategorydescription, location FROM procedureevents_mv WHERE hadm_id IN ({hadm_list})", 'procedureevents_mv')
        else:
            raise RuntimeError("No hadm_ids after LOS filter; cannot extract modalities.")
    else:
        demo = get_demographics(client, first_adm['subject_id'].dropna().astype(int).tolist())  # type: ignore
        vitals = get_vitals_48h(client, hadm_ids)  # type: ignore
        labs = get_labs_48h(client, hadm_ids)  # type: ignore
        rx = get_prescriptions_48h(client, hadm_ids)  # type: ignore
        proc = get_procedures_48h(client, hadm_ids)  # type: ignore
    # Runtime debug: report modality extraction sizes
    print('DEBUG: modality sizes -> demo:', len(demo), 'vitals:', len(vitals), 'labs:', len(labs), 'rx:', len(rx), 'proc:', len(proc))

    # 3) Build features
    # Reload features module dynamically so that notebook edits to features.py are reflected without kernel restart.
    try:
        from . import features as _features_mod  # type: ignore
        importlib.reload(_features_mod)
        features = _features_mod.build_features(first_adm, demo, vitals, labs, rx, proc)
    except Exception as _reload_err:  # fallback to already imported build_features
        print('DEBUG WARNING: failed to reload features module ->', _reload_err)
        features = build_features(first_adm, demo, vitals, labs, rx, proc)
    # Runtime debug: features shape before alignment
    print('DEBUG: raw features shape ->', getattr(features, 'shape', 'N/A'))
    # Defensive: remove leaky realized LOS feature if present (older artifacts may include it)
    if 'los_hours' in features.columns:
        features = features.drop(columns=['los_hours'])

    # 4) Load artifacts strictly from MLHC_MODELS_DIR (no discovery fallback)
    # Resolve models directory relative to this file (project/models)
    models_dir = os.path.normpath(os.path.join(os.path.dirname(__file__), 'artifacts'))
    required_files = [
        'feature_columns.json',
        'model_mortality.joblib',
        'model_prolonged_los.joblib',
        'model_readmission.joblib'
    ]
    missing_required = [f for f in required_files if not os.path.exists(os.path.join(models_dir, f))]
    if missing_required:
        raise FileNotFoundError(
            'Model artifacts missing in expected directory ' + models_dir + '. Missing: ' + ', '.join(missing_required)
        )
    feat_cols_path = os.path.join(models_dir, 'feature_columns.json')
    m_mort_path = os.path.join(models_dir, 'model_mortality.joblib')
    m_los_path = os.path.join(models_dir, 'model_prolonged_los.joblib')
    m_readm_path = os.path.join(models_dir, 'model_readmission.joblib')
    with open(feat_cols_path, 'r', encoding='utf-8') as f:
        feature_cols = json.load(f)
    print(f"Loading: {m_mort_path}")
    model_mort = joblib.load(m_mort_path)
    print(f"Loading: {m_los_path}")
    model_los = joblib.load(m_los_path)
    print(f"Loading: {m_readm_path}")
    model_readm = joblib.load(m_readm_path)
    preprocessor = None
    preprocessor_path = os.path.join(models_dir, 'preprocessor.joblib')
    if os.path.exists(preprocessor_path):
        try:
            print(f"Loading: {preprocessor_path}")
            preprocessor = joblib.load(preprocessor_path)
        except Exception as e:
            print('WARNING: failed to load preprocessor.joblib; proceeding without it ->', e)
    else:
        print('INFO: preprocessor.joblib not found; proceeding with raw feature matrix (assumed tree models).')

    # 5) Align feature columns (vectorized to avoid fragmentation)
    missing_cols = [c for c in feature_cols if c not in features.columns]
    # Runtime debug: report missing train-time feature columns that were not extracted
    print('DEBUG: missing feature cols count ->', len(missing_cols))
    if missing_cols:
        print('DEBUG: sample missing cols ->', missing_cols[:10])
        raise RuntimeError(
            f"Feature extraction incomplete; {len(missing_cols)} required training columns missing. First few: {missing_cols[:10]}"
        )
    # Reorder exactly as training feature column order
    features = features.reindex(columns=feature_cols, fill_value=0)
    # Runtime debug: final feature matrix shape (rows = subjects retained post-filter)
    print('DEBUG: final aligned features shape ->', getattr(features, 'shape', 'N/A'))
    if not feature_cols:
        raise RuntimeError("Loaded feature_columns.json is empty; cannot score.")
    if features.empty:
        raise RuntimeError("Feature matrix empty after alignment; cannot score.")
    X = features[feature_cols].copy()

    # 6) Transform and predict
    if preprocessor is not None:
        X_t = preprocessor.transform(X)
    else:
        # Assume models are tree-based and can consume raw numeric matrix; ensure no NaNs
        if X.isna().any().any():
            X = X.fillna(0.0)
        X_t = X.values
    mort_proba = model_mort.predict_proba(X_t)[:, 1]
    los_proba = model_los.predict_proba(X_t)[:, 1]
    readm_proba = model_readm.predict_proba(X_t)[:, 1]

    # 7) Build output
    out = pd.DataFrame({
        'subject_id': X.index.astype(int),
        'mortality_proba': mort_proba,
        'prolonged_LOS_proba': los_proba,
        'readmission_proba': readm_proba,
    })
    missing = set(subject_ids) - set(out['subject_id'].tolist())
    print('DEBUG: subjects missing after prediction ->', len(missing))
    if missing:
        raise RuntimeError(
            f"Predictions produced for only {len(out)} of {len(subject_ids)} subjects. Missing subject_ids: {list(missing)[:10]}"
        )
    return out.sort_values('subject_id').reset_index(drop=True)
